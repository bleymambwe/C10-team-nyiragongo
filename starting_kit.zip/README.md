# Starting kit

Welcome to the starting kit of the "Latent Probe Challenge - Toxicity Detection" competition.

You will find here what you need to make your first submission:

- `classifier.py`: an example classifier that loads a pre-trained model and predicts only
  (no training happens on the platform).
- `trained_probe.joblib`: an example pre-trained model file (placeholder), loaded by `classifier.py`.

## How to build your real submission

1. Train your linear probe locally (e.g. with `latent_probe_pipeline.py`), using the
   Gemma layer embeddings and labels for this task.
2. Save your trained probe with `joblib.dump(your_model, 'trained_probe.joblib')`.
3. Keep `classifier.py`'s interface exactly as-is (a class named `Classifier` with a
   `predict(self, X)` method) -- only change what happens inside `__init__` and `predict`
   if your model needs different loading logic (e.g. a PyTorch `.pt` file instead of joblib).
4. Zip `classifier.py` and `trained_probe.joblib` together at the ROOT of the zip
   (not inside a subfolder) -- this is your submission file.
5. Go to "My Submissions" on the competition page and upload that zip.

## Do NOT

- Do not call `.fit()` on the platform -- training must be done before you submit.
- Do not upload an untrained model.
- Do not place your files inside an extra folder inside the zip.
