import joblib
import numpy as np
from pathlib import Path


class Classifier:
    def __init__(self):
        self.artifact = joblib.load(Path(__file__).with_name("trained_probe.joblib"))

    @staticmethod
    def _probability(component, X):
        z = X
        if component["row_l2"]:
            z = z / np.maximum(np.linalg.norm(z, axis=1, keepdims=True), 1e-8)
        z = z[:, component["features"]]
        z = (z - component["center"]) / component["scale"]
        logits = z @ component["coef"].T + component["intercept"]
        return 1.0 / (1.0 + np.exp(-np.clip(logits.ravel(), -40, 40)))

    def predict(self, X):
        X = np.asarray(X, dtype=np.float32)
        expected = int(self.artifact["n_features"])
        if X.ndim != 2 or X.shape[1] != expected:
            raise ValueError(f"Expected [n, {expected}] embeddings; got {X.shape}")
        probability = np.zeros(len(X), dtype=np.float64)
        for weight, component in zip(self.artifact["weights"], self.artifact["components"]):
            probability += float(weight) * self._probability(component, X)
        if "threshold" == "threshold":
            return (probability >= float(self.artifact["threshold"])).astype(np.int64)
        count = int(round(len(X) * (None / 1700.0)))
        count = min(max(count, 0), len(X))
        prediction = np.zeros(len(X), dtype=np.int64)
        if count:
            prediction[np.argpartition(probability, len(X) - count)[-count:]] = 1
        return prediction
